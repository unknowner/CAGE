// index / home
tools.Page.runtime['symbols.php'] = function() {

	tools.Demi.parse($('#results_main_wrapper'));

};
