// index / home
tools.Page.runtime['treasure_chest.php'] = function () {
	
	$('#app_body div[style*="z-index:10"]').css('zIndex', 1);
	
};
